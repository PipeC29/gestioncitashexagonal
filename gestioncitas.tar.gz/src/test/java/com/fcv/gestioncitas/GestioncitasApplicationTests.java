package com.fcv.gestioncitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioncitasApplicationTests {

	@Test
	void contextLoads() {
	}

}
