package com.fcv.gestioncitas.domain.port.in;

import com.fcv.gestioncitas.domain.model.Doctor;

public interface CrearDoctorUseCase {
    Doctor crear(Doctor doctor);
}
