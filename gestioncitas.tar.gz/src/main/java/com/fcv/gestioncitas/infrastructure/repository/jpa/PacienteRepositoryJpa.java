package com.fcv.gestioncitas.infrastructure.repository.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepositoryJpa extends JpaRepository<PacienteEntity, Long> {
}
