package com.fcv.gestioncitas.exception;

public class AgendaOcupadaException extends RuntimeException {
    public AgendaOcupadaException(String mensaje) {
        super(mensaje);
    }
}
